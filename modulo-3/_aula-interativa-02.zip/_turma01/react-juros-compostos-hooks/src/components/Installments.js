import React from 'react';

export default function Installments({ children }) {
  return <div className='row'>{children}</div>;
}
