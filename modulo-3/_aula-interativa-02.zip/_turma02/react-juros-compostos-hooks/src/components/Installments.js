import React from 'react';

export default function Installments({ children: installments }) {
  return <div className='row'>{installments}</div>;
}
